import React , {Component} from 'react';
import './ViewContact.css';
import ContactDetails from '../../../components/ContactDetails/ContactDetails';


class ViewContact extends Component {
    state = {
        toShow : false,
        
    }
    showDetails = () =>{
        this.setState({toShow : true});
        
    }
    hideDetails = () => {
        this.setState({toShow : false});
    }

    render(){
        var conStyle = {
            paddingRight : "657px"
        }
        return(
            <div>
            <div className = "ViewContact" onMouseOver = {this.showDetails} onMouseOut = {this.hideDetails}>
                    
                       <p style = {conStyle}>{this.props.conName} </p> 
                   
                        <p>{this.props.company}</p>
                    
            </div>
            {this.state.toShow === true ?
            <div>
            
                <ContactDetails conName = {this.props.conName} toShow = {this.state.toShow}/>
               
            </div> : null
            }
                
            </div>
             
        )
        
        
    }
}



export default ViewContact;