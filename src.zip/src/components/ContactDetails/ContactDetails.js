import React , {Component} from 'react';
import './ContactDetails.css';


class ContactDetails extends Component{
    render(){
        return(
           
                
                <div className = "ContactDetails">
                        <p>Full Name : {this.props.conName}</p>
                        <p>Phone no: 123456789</p>
                        <p>Email id : {this.props.conName}@gmail.com</p>
                </div> 
                
            
            
        );
    }

}


export default ContactDetails;